# Techkartel
