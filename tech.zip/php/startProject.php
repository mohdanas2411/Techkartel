<!DOCTYPE html> 
	<?php 
		$cusName = $_POST["cus_name"];
		$phone = $_POST["phone"];
		$email = $_POST["email"];
		$projecType = $_POST["project_type"];
		$projectDesc = $_POST["project_Desc"];

		$servername = "localhost";
		$username = "id13007440_admin";
		$password = "&$<01}E$gT64Jnyk";
		$dbname = "id13007440_techkartel";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
		}

		$sql = "INSERT INTO NewProjectDetails (customerName, phone, email,projecType,projectDesc)
		VALUES ("$cusName", "$phone", "$email","$projecType","$projectDesc");";

		if ($conn->multi_query($sql) === TRUE) {
		    echo "Details saved successfully";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();
	?>
</html>